#!/usr/bin/env python3
"""
Automatically applies all Xabarchi rebranding, API credential injection,
Uzbek default localization, and iOS Liquid Glass UI patches to a DrKLO/Telegram fork.
Idempotent and safe to run inside GitHub Actions.
"""
import os
import re
import sys
from pathlib import Path


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def patch_once(path_str: str, marker: str, pattern: str, replacement: str, use_regex: bool = False) -> bool:
    p = Path(path_str)
    if not p.exists():
        print(f"[SKIP] File not found: {path_str}")
        return False
    src = read_text(p)
    if marker and marker in src:
        print(f"[OK]   Already patched ({marker}): {path_str}")
        return True
    if use_regex:
        new_src, count = re.subn(pattern, replacement, src, count=1, flags=re.MULTILINE)
    else:
        if pattern in src:
            new_src = src.replace(pattern, replacement, 1)
            count = 1
        else:
            new_src, count = src, 0
    if count > 0:
        write_text(p, new_src)
        print(f"[PATCH] Applied to {path_str}")
        return True
    print(f"[WARN] Anchor not matched in {path_str} (upstream code may have changed slightly)")
    return False


def patch_build_vars():
    api_id = os.environ.get("TELEGRAM_API_ID", "").strip()
    api_hash = os.environ.get("TELEGRAM_API_HASH", "").strip()
    if not api_id or not api_hash:
        print("ERROR: TELEGRAM_API_ID and TELEGRAM_API_HASH GitHub Secrets are required!", file=sys.stderr)
        sys.exit(1)
    if not api_id.isdigit():
        print("ERROR: TELEGRAM_API_ID must contain only digits!", file=sys.stderr)
        sys.exit(1)

    p = Path("TMessagesProj/src/main/java/org/telegram/messenger/BuildVars.java")
    if not p.exists():
        print("ERROR: BuildVars.java not found! Are you running inside a DrKLO/Telegram fork?", file=sys.stderr)
        sys.exit(1)
    src = read_text(p)
    src = re.sub(r'public static int APP_ID\s*=\s*[^;]+;', f'public static int APP_ID = {api_id};', src, count=1)
    src = re.sub(r'public static String APP_HASH\s*=\s*"[^"]*";', f'public static String APP_HASH = "{api_hash}";', src, count=1)
    src = re.sub(r'public static boolean CHECK_UPDATES\s*=\s*true;', 'public static boolean CHECK_UPDATES = false;', src)
    src = re.sub(r'public static boolean IS_BILLING_UNAVAILABLE\s*=\s*false;', 'public static boolean IS_BILLING_UNAVAILABLE = true;', src)
    src = re.sub(r'public static boolean SUPPORTS_PASSKEYS\s*=\s*true;', 'public static boolean SUPPORTS_PASSKEYS = false;', src)
    src = re.sub(r'public static boolean SUPPORTS_FPNV\s*=\s*true;', 'public static boolean SUPPORTS_FPNV = false;', src)
    src = re.sub(r'public static String SAFETYNET_KEY\s*=\s*"[^"]*";', 'public static String SAFETYNET_KEY = "";', src)
    src = re.sub(r'public static String PLAYSTORE_APP_URL\s*=\s*"[^"]*";', 'public static String PLAYSTORE_APP_URL = "";', src)
    src = re.sub(r'public static String HUAWEI_STORE_URL\s*=\s*"[^"]*";', 'public static String HUAWEI_STORE_URL = "";', src)
    src = re.sub(r'public static String GOOGLE_AUTH_CLIENT_ID\s*=\s*"[^"]*";', 'public static String GOOGLE_AUTH_CLIENT_ID = "";', src)
    write_text(p, src)
    print("[PATCH] Injected API credentials and fork flags into BuildVars.java")


def patch_gradle_and_manifest():
    app_gradle = Path("TMessagesProj_App/build.gradle")
    if app_gradle.exists():
        src = read_text(app_gradle)
        src = src.replace('applicationId "org.telegram.messenger"', 'applicationId "com.xabarchi.app"')
        src = src.replace("applicationId 'org.telegram.messenger'", "applicationId 'com.xabarchi.app'")
        if 'abiFilters "arm64-v8a"' not in src and "abiFilters 'arm64-v8a'" not in src:
            src = re.sub(
                r'(defaultConfig\s*\{)',
                '\\1\n        ndk {\n            abiFilters "arm64-v8a"\n        }',
                src,
                count=1,
            )
        write_text(app_gradle, src)
        print("[PATCH] Updated TMessagesProj_App/build.gradle (com.xabarchi.app + arm64-v8a)")

    lib_gradle = Path("TMessagesProj/build.gradle")
    if lib_gradle.exists():
        src = read_text(lib_gradle)
        if "androidx.dynamicanimation:dynamicanimation" not in src:
            src = re.sub(
                r'(dependencies\s*\{)',
                '\\1\n    implementation "androidx.dynamicanimation:dynamicanimation:1.0.0"',
                src,
                count=1,
            )
            write_text(lib_gradle, src)
            print("[PATCH] Added androidx.dynamicanimation to TMessagesProj/build.gradle")

    manifest = Path("TMessagesProj/src/main/AndroidManifest.xml")
    if manifest.exists():
        src = read_text(manifest)
        src = src.replace('android:label="@string/AppName"', 'android:label="@string/XabarchiAppName"')
        src = src.replace('android:authorities="org.telegram.messenger.', 'android:authorities="${applicationId}.')
        write_text(manifest, src)
        print("[PATCH] Updated TMessagesProj/src/main/AndroidManifest.xml")

    for str_path in [
        "TMessagesProj/src/main/res/values/strings.xml",
        "TMessagesProj/src/main/res/values-ru/strings.xml",
    ]:
        sp = Path(str_path)
        if sp.exists():
            s = read_text(sp)
            s = s.replace('<string name="AppName">Telegram</string>', '<string name="AppName">Xabarchi</string>')
            s = s.replace('<string name="AppNameBeta">Telegram Beta</string>', '<string name="AppNameBeta">Xabarchi Beta</string>')
            write_text(sp, s)
            print(f"[PATCH] Rebranded AppName in {str_path}")


def patch_localization():
    patch_once(
        "TMessagesProj/src/main/java/org/telegram/messenger/LocaleController.java",
        "isFirstUzLocaleApplied",
        "if (currentInfo == null) {\n            currentInfo = getLanguageFromDict(systemDefaultLocale.getLanguage());\n        }",
        """if (currentInfo == null && !org.telegram.ui.xabarchi.LiquidGlassConfig.isFirstUzLocaleApplied()) {
            org.telegram.ui.xabarchi.LiquidGlassConfig.markFirstUzLocaleApplied();
            LocaleInfo uz = getLanguageFromDict("uz");
            if (uz == null) {
                uz = new LocaleInfo();
                uz.name = "O\\u02bbzbekcha";
                uz.nameEnglish = "Uzbek";
                uz.shortName = uz.pluralLangCode = "uz";
                uz.builtIn = true;
                languages.add(0, uz);
                languagesDict.put(uz.getKey(), uz);
            }
            currentInfo = uz;
        }
        if (currentInfo == null) {
            currentInfo = getLanguageFromDict(systemDefaultLocale.getLanguage());
        }""",
    )

    lc_path = Path("TMessagesProj/src/main/java/org/telegram/messenger/LocaleController.java")
    if lc_path.exists():
        src = read_text(lc_path)
        if "pinXabarchiLanguages(" not in src:
            helper = """
    public void pinXabarchiLanguages(ArrayList<LocaleInfo> list) {
        if (list == null) {
            return;
        }
        String[] priority = new String[]{"uz", "ru", "en"};
        int insertAt = 0;
        for (String code : priority) {
            LocaleInfo found = null;
            for (int i = 0; i < list.size(); i++) {
                if (code.equalsIgnoreCase(list.get(i).shortName)) {
                    found = list.remove(i);
                    break;
                }
            }
            if (found == null && "uz".equals(code)) {
                found = new LocaleInfo();
                found.name = "O\\u02bbzbekcha";
                found.nameEnglish = "Uzbek";
                found.shortName = found.pluralLangCode = "uz";
                found.builtIn = true;
                languagesDict.put(found.getKey(), found);
            }
            if (found != null) {
                list.add(insertAt++, found);
            }
        }
    }
}
"""
            idx = src.rfind("}")
            if idx != -1:
                src = src[:idx] + helper
                write_text(lc_path, src)
                print("[PATCH] Added pinXabarchiLanguages() to LocaleController.java")

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/LanguageSelectActivity.java",
        "pinXabarchiLanguages",
        r'(Collections\.sort\(sortedLanguages,[\s\S]*?\);)',
        '\\1\n        LocaleController.getInstance().pinXabarchiLanguages(sortedLanguages);',
        use_regex=True,
    )


def patch_liquid_glass_ui():
    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/Theme.java",
        "LiquidGlassConfig.IOS_BLUE",
        "defaultColors.put(key_chats_unreadCounter, 0xff4ecc5e);",
        "defaultColors.put(key_chats_unreadCounter, org.telegram.ui.xabarchi.LiquidGlassConfig.IOS_BLUE);",
    )
    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/Theme.java",
        "AUTO_NIGHT_TYPE_SYSTEM; // xabarchi",
        "if (selectedAutoNightType == AUTO_NIGHT_TYPE_NONE) {\n            return;\n        }",
        "if (selectedAutoNightType == AUTO_NIGHT_TYPE_NONE) {\n            selectedAutoNightType = AUTO_NIGHT_TYPE_SYSTEM; // xabarchi\n        }",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/ActionBar.java",
        "xabarchiGlassBg",
        "setOnClickListener(v -> {",
        "org.telegram.ui.xabarchi.GlassDrawable xabarchiGlassBg = new org.telegram.ui.xabarchi.GlassDrawable(context, 24f);\n        setBackground(xabarchiGlassBg);\n        setElevation(AndroidUtilities.dp(8));\n        setOnClickListener(v -> {",
    )
    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/ActionBar.java",
        "ic_xabarchi_back_chevron",
        "backButtonImageView.setImageResource(resource);",
        "backButtonImageView.setImageResource(resource == R.drawable.ic_ab_back ? R.drawable.ic_xabarchi_back_chevron : resource);",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/ActionBarPopupWindow.java",
        "GlassDrawable.applyAsBackground",
        "setBackgroundDrawable(backgroundDrawable);",
        "org.telegram.ui.xabarchi.GlassDrawable.applyAsBackground(this, 20f);",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/BottomSheet.java",
        "GlassDrawable.applyAsBackground",
        "containerView.setBackgroundDrawable(shadowDrawable);",
        "org.telegram.ui.xabarchi.GlassDrawable.applyAsBackground(containerView, 28f);\n        containerView.setElevation(AndroidUtilities.dp(16));",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/ActionBar/AlertDialog.java",
        "GlassDrawable.applyAsBackground",
        "contentView.setBackgroundDrawable(shadowDrawable);",
        "org.telegram.ui.xabarchi.GlassDrawable.applyAsBackground(contentView, 24f);",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/Components/Bulletin.java",
        "GlassDrawable.applyAsBackground",
        "setBackground(Theme.createRoundRectDrawable(AndroidUtilities.dp(10), backgroundColor));",
        "org.telegram.ui.xabarchi.GlassDrawable.applyAsBackground(this, 20f);",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/DialogsActivity.java",
        "LiquidGlassWallpaperDrawable",
        "contentView.setBackgroundColor(Theme.getColor(Theme.key_windowBackgroundWhite));",
        "contentView.setBackground(new org.telegram.ui.xabarchi.LiquidGlassWallpaperDrawable(context));",
    )

    patch_once(
        "TMessagesProj/src/main/java/org/telegram/ui/Cells/DialogCell.java",
        "// xabarchi_avatar",
        "avatarImage.setRoundRadius(AndroidUtilities.dp(28));",
        "avatarImage.setRoundRadius(AndroidUtilities.dp(27)); // xabarchi_avatar",
    )

    # LaunchActivity.java: Floating LiquidGlassTabBar + parallax slide
    la_path = Path("TMessagesProj/src/main/java/org/telegram/ui/LaunchActivity.java")
    if la_path.exists():
        src = read_text(la_path)
        if "xabarchiTabBar" not in src:
            anchor = "drawerLayoutContainer.addView(actionBarLayout"
            idx = src.find(anchor)
            if idx != -1:
                line_end = src.find(");", idx)
                if line_end != -1:
                    inject = """
        actionBarLayout.setUseAlphaAnimations(false);
        final org.telegram.ui.xabarchi.LiquidGlassTabBar xabarchiTabBar = new org.telegram.ui.xabarchi.LiquidGlassTabBar(this);
        xabarchiTabBar.setBackdropSourceRoot(actionBarLayout);
        xabarchiTabBar.setOnTabSelectedListener(tabIndex -> {
            if (tabIndex == org.telegram.ui.xabarchi.LiquidGlassTabBar.TAB_CHATS) {
                actionBarLayout.rebuildFragments(0);
            } else if (tabIndex == org.telegram.ui.xabarchi.LiquidGlassTabBar.TAB_CONTACTS) {
                actionBarLayout.presentFragment(new ContactsActivity(null), false, false, true, false);
            } else if (tabIndex == org.telegram.ui.xabarchi.LiquidGlassTabBar.TAB_CALLS) {
                actionBarLayout.presentFragment(new CallLogActivity(), false, false, true, false);
            } else if (tabIndex == org.telegram.ui.xabarchi.LiquidGlassTabBar.TAB_SETTINGS) {
                actionBarLayout.presentFragment(new org.telegram.ui.xabarchi.XabarchiSettingsActivity(), false, false, true, false);
            }
        });
        FrameLayout.LayoutParams xabarchiTabLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                AndroidUtilities.dp(62),
                android.view.Gravity.BOTTOM
        );
        xabarchiTabLp.leftMargin = AndroidUtilities.dp(16);
        xabarchiTabLp.rightMargin = AndroidUtilities.dp(16);
        xabarchiTabLp.bottomMargin = AndroidUtilities.dp(14) + AndroidUtilities.navigationBarHeight;
        drawerLayoutContainer.addView(xabarchiTabBar, xabarchiTabLp);
"""
                    src = src[: line_end + 2] + inject + src[line_end + 2 :]
                    write_text(la_path, src)
                    print("[PATCH] Added LiquidGlassTabBar to LaunchActivity.java")


if __name__ == "__main__":
    patch_build_vars()
    patch_gradle_and_manifest()
    patch_localization()
    patch_liquid_glass_ui()
    print("=== All Xabarchi patches finished ===")
